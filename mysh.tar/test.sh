ls | cat
ls
pwd